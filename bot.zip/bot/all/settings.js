require("./module")

global.owner = "6282386179583"
global.ownerStore = "6282386179583"
global.pairingNumber = "6282386179583"
global.namabot = "Rimuru Store"
global.namaCreator = "Rimuru Store"
global.namaStore = "RimuruStore"
global.nodana = "082386179583"
global.nogopay = "082386179583"
global.antilink = false
global.versisc = '1.0.0'
global.namasc = 'Yann Dev'
global.domain = '-' // Isi Domain Lu
global.apikey = '-' // Isi Apikey Plta Lu
global.capikey = '-' // Isi Apikey Pltc Lu
global.domainotp = "-" // Isi Sendiri
global.apikeyotp = "" // Isi Sendiri
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
global.thumb = fs.readFileSync("./thumb.png")
global.audionya = fs.readFileSync("./all/sound.mp3")
global.tekspushkon = "" // Biarin Aja
global.tekspushkonv2 = "" // Biarin Aja
global.tekspushkonv3 = "" // Biarin Aja
global.tekspushkonv4 = "" // Biarin Aja
global.packname = ""
global.author = "Sticker By 082386179583"
global.jumlah = "5"
global.youtube = -" // Isi Sendiri
global.grup = "-" // Isi Sendiri
global.telegram = "-" // Isi Sendiri
global.instagram = "-" // Isi Sendiri

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})