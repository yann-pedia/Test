
hii 

Ini adalah script store by Rafael 
script ini di buat untuk mempermudah kalian dalam berjualan panel maupun yang lainnya 
dalam script ini terdapat banyak sekali menu yg dapat di gunakan 

setting owner di ./all/database/owner.json
setting nama bot nama owner dll di ./all.settings.js


Script ini di jual 
no enc 100% : 20k
sudah free update 2 kali ya
juka berminat bisa hubungi

wa.me/6283857564133